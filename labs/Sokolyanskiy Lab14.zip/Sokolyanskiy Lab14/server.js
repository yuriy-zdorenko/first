const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Роут для головної сторінки з посиланнями
app.get('/', (req, res) => {
    res.send(`
        <h1>Лабораторна робота: Веб-програмування</h1>
        <ul>
            <li><a href="/task1">Завдання 1 (Адаптивна розмітка сторінки)</a></li>
            <li><a href="/task2">Завдання 2 (Кольорові блоки)</a></li>
        </ul>
    `);
});

// Роут для Завдання 1
app.get('/task1', (req, res) => {
    res.sendFile(path.join(__dirname, 'task1.html'));
});

// Роут для Завдання 2
app.get('/task2', (req, res) => {
    res.sendFile(path.join(__dirname, 'task2.html'));
});

// Запуск сервера
app.listen(port, () => {
    console.log(`Сервер успішно запущено! Відкрийте браузер за адресою: http://localhost:${port}`);
});